<?php
namespace NotaFiscal\Controllers;


class IndexController extends ControllerBase
{
    
    public function indexAction()
    {
    }
    
}